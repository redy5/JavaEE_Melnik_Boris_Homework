package sys;

public interface TeachersDao {
	public void addTeacher(Teacher teacher);

	public Teacher getTeacherById(int id);

}
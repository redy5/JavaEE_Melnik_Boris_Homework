package sys;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

public class WorkWithTeacher {
	@Autowired
	TeachersDao teachersDao;

	public Teacher addTeacher(Teacher teacher) {
		teacher = teachersDao.addTeacher(teacher);
		System.out.println(teacher);
		return teacher;
	}
	
	public Teacher getTeacher(int id) {
		Teacher l = teachersDao.getTeacherById(id);
		System.out.println(l);
		return l;
	}

	public void saveTeacher(Teacher teacher) {
		System.out.println(teacher);
		teachersDao.saveTacher(teacher);
	}
}
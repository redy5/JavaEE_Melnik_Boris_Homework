package sys;

import org.springframework.beans.factory.annotation.Autowired;

public class WorkWithStudents {
	@Autowired
	StudentsDao studentsDao;

	public Student addStudent(Student student) {
		student = studentsDao.addStudent(student);
		System.out.println(student);
		return student;
	}
	
	public Student getStudent(int id) {
		Student s = studentsDao.getStudent(id);
		System.out.println(s);
		return s;
	}

	public void saveStudent(Student student) {
		System.out.println(student);
		studentsDao.saveStudent(student);
	}
	
	
}
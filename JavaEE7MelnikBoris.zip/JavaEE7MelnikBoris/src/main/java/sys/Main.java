package sys;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] arg0) {
		ApplicationContext context = new ClassPathXmlApplicationContext("SpringBeans.xml");
		
		Lecture l = new Lecture();
		Teacher t = new Teacher();
		Student s = new Student();
		s.setPib("Gregory Andrushak");
		s.setCourse(3);
		List<Student> ls = new ArrayList<Student>();
		ls.add(s);
		t.setFirstname("Boris");
		t.setLastname("Melnik");
		l.setName("Introduction to Spring");
		l.setCredits(2.5);
		List<Lecture> le = new ArrayList<Lecture>();
		le.add(l);
		t.setLectures(le);
	}
}